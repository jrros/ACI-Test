# aci-postman

This repo contains a couple of ACI postman collections I picked up somewhere
along the way, unfortunately I don't remember where so I can't give them credit

Here are a few handy links to get them imported into your environment.

## ACI_QUERY_OBJECTS

[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/0c2c612a3c22d699d1d4)

## ACI_CREATE_OBJECTS

[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/0023d2be7a25c432668f)

# Configuration

You'll need to create an environment in Postman and set the following variables

* apic_ip
* apic_username
* apic_password
